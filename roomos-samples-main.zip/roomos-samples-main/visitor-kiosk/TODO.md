# TODO

- Sign out: check if email has actually checked in, error msg if not
- Send card instead of message to host (create smaller photo)
- ... and show this card as confirmation page

- Go home after timeout on last page
- Also send message to a common space
- Translate to french too?


## Feature ideas

- Taxi
- Office map
- While you are waiting: Coffee info | Toilet
- Checkout: scan QR
- Try this as touch app on navigator too
