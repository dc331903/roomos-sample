## TODO

* Make prettier
* Back button
* Close button on qr code
* Make qr link more visible
* Show alert on osd that navigator opened dialog
