# Navigator Web App

This sample shows an app that can run on the Webex Navgiator and talk to the xAPI of the video device.

[Launch App](./index.html)
